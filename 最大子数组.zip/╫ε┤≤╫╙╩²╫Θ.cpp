#include <stdio.h>
#include<stdlib.h>
#include<string.h>
int main() 
{
	int a[100]={0};
	char ch;
	int max=0;
	int num=0;
	for(int i=0; ;i++)
	{
		scanf("%d",&a[i]);
		ch=getchar();
		if(ch=='\n')
		{
			break;
		}
		num=num+a[i];
		if(num>max)
		{
			max=num;
		}
		if(num<0)
		{
			num=0;
		}

	}
    printf("%d",max);
	system("pause");
    return 0;
}
